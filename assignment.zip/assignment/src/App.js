import './App.css';
import Landing from './JS/Landing'
function App() {
  return (
    <div className="App">
      <Landing />
    </div>
  );
}

export default App;
